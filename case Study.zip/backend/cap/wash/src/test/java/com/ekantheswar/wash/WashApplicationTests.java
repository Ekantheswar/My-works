package com.ekantheswar.wash;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ekantheswar.wash.services.washService;

@SpringBootTest
class WashApplicationTests {

	
	@Autowired
	private washService service;
	@Test
	void contextLoads() {
	}
	
	@Test
	@DisplayName("testing get user by ")
	void context() {
		
		assertNotEquals(0, service.getwashRequests());
	}


}
