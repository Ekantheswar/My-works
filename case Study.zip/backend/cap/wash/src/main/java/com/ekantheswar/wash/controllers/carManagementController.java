package com.ekantheswar.wash.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ekantheswar.wash.exception.NotFoundException;
import com.ekantheswar.wash.models.carManagementData;
import com.ekantheswar.wash.services.carManagementService;

@RestController
@RequestMapping("/carManage")
@CrossOrigin()
public class carManagementController {
	@Autowired
	private carManagementService car;
	
	@GetMapping("/getCars")
	public List<carManagementData> getusers()
	{
		return car.getcars();
	}
	
	@GetMapping("/getCar/{name}")
	public List<carManagementData> getUserByName(@PathVariable String name)
	{
		return car.getCarByName(name);
	}
	@PostMapping("/addCar")
	public String saveCar( @RequestBody carManagementData data) 
	{
		return car.saveCar(data);
	}
	@PutMapping("/updatecar/{s}")
	public String updateCar(@RequestBody carManagementData d,@PathVariable String s)
	{
		return  car.updateCar(d, s);
	    
	}
	
	@DeleteMapping("/removeCar/{s}")
	public String deleteCar(@PathVariable String s){
		return car.deleteCar(s);
		
	}
	
	@DeleteMapping("/removeCars")
	public String removeAll()
	{
		return car.removeAll();
	}
	


}
