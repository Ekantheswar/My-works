package com.ekantheswar.wash.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ekantheswar.wash.models.scheduleLater;

import com.ekantheswar.wash.repositories.washLater;

@Service
public class scheduleLaterService {
	
	@Autowired
	private washLater later;
	
	public String addOrder( scheduleLater data) 
	{
		later.save(data);
		return"added successfully";
	}

	public List<scheduleLater> getwashRequests()
	{
		return later.findAll();
	}
	
	public List<scheduleLater> getrequestByCarNumber( String c_number)
	{
		return later.findByc_number(c_number);
	}
}
