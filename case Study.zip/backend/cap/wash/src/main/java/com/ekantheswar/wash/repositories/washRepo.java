package com.ekantheswar.wash.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Repository;

import com.ekantheswar.wash.models.carManagementData;
import com.ekantheswar.wash.models.servicePlanData;

@EnableMongoRepositories
@Repository

public interface washRepo  extends MongoRepository<carManagementData, String>{
	
	@Query("{'name':?0}")
	   List<carManagementData> findByName(String name);
	   @Query("{'w_name':?0}")
	   List<carManagementData> findBywasherName(String w_name);
	
	   
	   @DeleteQuery
	   String deleteByName(String name);
	   
	   

}
