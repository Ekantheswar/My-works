package com.ekantheswar.wash.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ekantheswar.wash.exception.NotFoundException;
import com.ekantheswar.wash.models.carManagementData;
import com.ekantheswar.wash.models.servicePlanData;
import com.ekantheswar.wash.repositories.washRepo;


@Service
public class carManagementService {
	@Autowired
	private washRepo washrepo;
	
	
	public String saveCar( carManagementData data) 
	{
		washrepo.save(data);
		return"added successfully";
	}

	public String updateCar(carManagementData d, String s)
	{
		List<carManagementData> saved = washrepo.findByName(s);
	    if(saved.size()==0){
	      throw new NotFoundException("Car with the id "+ s + "not exist");}
	    washrepo.save(d);
	    return "Car Updated Successfully!!";
	    
	}
	
	
	public String deleteCar(String s)
	{
		List<carManagementData> saved = washrepo.findByName(s);
	    if(saved.size()==0){
	      throw new NotFoundException("Car with the id "+ s + "not exist");}
	    washrepo.deleteByName(s);
	    return "Car deleted Successfully!!";
	    
	}

	
	
	public List<carManagementData> getcars()
	{
		return washrepo.findAll();
	}
	public List<carManagementData> getCarByName( String name)
	{
		return washrepo.findByName(name);
	}

	

	
	
	public String removeAll()
	{
		washrepo.deleteAll();
		return "deleted Successfully";
	}
}
