package com.ekantheswar.wash.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ekantheswar.wash.models.servicePlanData;
import com.ekantheswar.wash.services.servicePlanService;

@RestController
@RequestMapping("/service")
@CrossOrigin()
public class servicePlanController {
	
	@Autowired
	private servicePlanService service;
	
	
	@GetMapping("/getServices")
	public List<servicePlanData> getusers()
	{
		return service.getServices();
	}
	
	@GetMapping("/getservice/{name}")
	public List<servicePlanData> getUserByName(@PathVariable String name)
	{
		return service.getServiceByName(name);
		}
	
	@PostMapping("/addService")
	public String saveService(@RequestBody servicePlanData data) 
	{
		return service.saveService(data);
		
	}
	
	@DeleteMapping("/removeService/{s}")
	public String deleteService(@PathVariable String s)
	{
		return service.deleteService(s);
	    
	}
	@DeleteMapping("/removeAll")
	public String removeAll()
	{
		return service.removeAll();
		
	}

}
