package com.ekantheswar.wash.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import com.ekantheswar.wash.models.washData;

public interface washOrderRepo extends MongoRepository<washData, String> {
	
	@Query("{'status':?0}")
	   List<washData> findByStatus(String status);
    @Query("{'w_name':?0}")
	   List<washData> findByWashername(String w_name);
	@Query("{'name':?0}")
	   List<washData> findByName(String name);

}
