package com.ekantheswar.wash.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Repository;

import com.ekantheswar.wash.models.scheduleLater;


@Repository
@EnableMongoRepositories
public interface washLater extends MongoRepository<scheduleLater, String> {
	
	@Query("{'w_name':?0}")
	   List<scheduleLater> findByWashername(String w_name);
	   
	@Query("{'name':?0}")
	   List<scheduleLater> findByName(String c_number);
	   
    @Query("{'c_number':?0}")
	   List<scheduleLater> findByc_number(String c_number);	   

}
