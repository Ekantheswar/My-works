package com.ekantheswar.wash.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ekantheswar.wash.models.washData;
import com.ekantheswar.wash.services.washService;

@RestController
@RequestMapping("/wash")
@CrossOrigin()
public class washController {
	@Autowired washService wash;
	
	@PostMapping("/addWashRequest")
	public String addOrder( @RequestBody washData data) 
	{
		return wash.addOrder(data);
	}
	
	@GetMapping("/getWashRequests")
	public List<washData> getusers()
	{
		return wash.getwashRequests();
	}
	
	@DeleteMapping("/deleteAll")
	public String removeall()

	{
		return wash.removeall();
	}
	@GetMapping("/getWashRequest/{status}")
	public List<washData> getUserByStatus( @PathVariable String status)
	{
		return wash.getUserByStatus(status);
	}
	
	@GetMapping("/receipt/{id}")
	public Optional<washData>getOrder(@PathVariable String id)
	{
		return wash.getOrderById(id);
		
	}
//////////

	@GetMapping("/getorders/{name}")
	public List<washData> getOrderByName(@PathVariable String name)
	{
		return wash.getOrderByName(name);
	}
	
	@GetMapping("/getorders/wash/{washername}")
	public List<washData> getOrderBywasherName(@PathVariable String w_name)
	{
		System.out.println(w_name+"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		return wash.getOrderBywasherName(w_name);
	}
	
	@PutMapping("/inprogress")
	public String changeStatusToInprogress(washData d, String s)
	{
		return wash.changeStatusToInprogress(d, s);
		    
		
	}
	
	@PutMapping("/completed")
	public String changeStatusToCompleted(washData d)
	{
		return wash.changeStatusToCompleted(d);
		    
		
	}

}
