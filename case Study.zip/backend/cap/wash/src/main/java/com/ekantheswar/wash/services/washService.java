package com.ekantheswar.wash.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ekantheswar.wash.models.washData;
import com.ekantheswar.wash.repositories.washOrderRepo;
import com.ekantheswar.wash.exception.*;

@Service
public class washService {
	@Autowired
	private washOrderRepo washorderrepo;
	
	public String addOrder( washData data) 
	{
		data.setCost("2000");
		data.setStatus("pending");
		washorderrepo.save(data);
		return"added successfully";
	}
	
	public List<washData> getwashRequests()
	{
		return washorderrepo.findAll();
	}
	public List<washData> getUserByStatus( String status)
	{
		return washorderrepo.findByStatus(status);
	}
	
	public String removeall()
	{
		washorderrepo.deleteAll();
		return "deleted Succesfully";
	}
	
	
	////////
	public String changeStatusToInprogress(washData d, String s)
	{
		
			Optional<washData> saved = washorderrepo.findById(s);
			d.setStatus("In progress");
			washorderrepo.save(d);
		    return "Status updated succesfully";
		    
		
	}
	
	public String changeStatusToCompleted(washData d)
	{
		
			Optional<washData> saved1 = washorderrepo.findById(d.get_id());
			d.setStatus("Completed");
			washorderrepo.save(d);
		    return "Status updated succesfully";
		    
		
	}
	
	public Optional<washData>getOrderById(String id)
	{


      Optional<washData> userId = washorderrepo.findById(id);
      if(!userId.isPresent()) {
        throw new NotFoundException("User with the id "+ id + " not exist");}
		return washorderrepo.findById(id);
		
	}
	
	public List<washData> getOrderByName( String name)
	{
		return washorderrepo.findByName(name);
	}
	
	public List<washData> getOrderBywasherName( String w_name)
	{
		return washorderrepo.findByWashername(w_name);
	}


}
