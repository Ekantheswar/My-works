package com.ekantheswar.wash.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="schedulelater")
public class scheduleLater {
	
	@Id
	private String _id;
	private String name;
	private String w_name;
	private String date;
	private String time;
	private String c_number;
	private String c_type;
	private String c_company;
	private String c_name;
	private String status;
	private String cost;
	public String get_id() {
		return _id;
	}
	public void set_id(String _id) {
		this._id = _id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getW_name() {
		return w_name;
	}
	public void setW_name(String w_name) {
		this.w_name = w_name;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getC_number() {
		return c_number;
	}
	public void setC_number(String c_number) {
		this.c_number = c_number;
	}
	public String getC_type() {
		return c_type;
	}
	public void setC_type(String c_type) {
		this.c_type = c_type;
	}
	public String getC_company() {
		return c_company;
	}
	public void setC_company(String c_company) {
		this.c_company = c_company;
	}
	public String getC_name() {
		return c_name;
	}
	public void setC_name(String c_name) {
		this.c_name = c_name;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	public scheduleLater(String _id, String name, String w_name, String date, String time, String c_number,
			String c_type, String c_company, String c_name, String status, String cost) {
		super();
		this._id = _id;
		this.name = name;
		this.w_name = w_name;
		this.date = date;
		this.time = time;
		this.c_number = c_number;
		this.c_type = c_type;
		this.c_company = c_company;
		this.c_name = c_name;
		this.status = status;
		this.cost = cost;
	}
	
}
