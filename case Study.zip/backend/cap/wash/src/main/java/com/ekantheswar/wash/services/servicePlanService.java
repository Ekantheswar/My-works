package com.ekantheswar.wash.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ekantheswar.wash.exception.NotFoundException;
import com.ekantheswar.wash.models.carManagementData;
import com.ekantheswar.wash.models.servicePlanData;
import com.ekantheswar.wash.repositories.serviceRepo;

@Service
public class servicePlanService {
	
	@Autowired
	private serviceRepo servicerepo;
	
	public String saveService( servicePlanData data) 
	{
		servicerepo.save(data);
		return"added successfully";
	}

	public String updateService(servicePlanData d, String s)
	{
		List<servicePlanData> saved = servicerepo.findByName(s);
	    if(saved.size()==0){
	      throw new NotFoundException("Car with the id "+ s + "not exist");}
	    servicerepo.save(d);
	    return "Car Updated Successfully!!";
	    
	}
	
	public String deleteService(String s)
	{
		List<servicePlanData> saved = servicerepo.findByName(s);
	    if(saved.size()==0){
	      throw new NotFoundException("Car with the id "+ s + "not exist");}
	    servicerepo.deleteByName(s);
	    return "Service deleted Successfully!!";
	    
	}
	
	public List<servicePlanData> getServices()
	{
		return servicerepo.findAll();
	}
	public List<servicePlanData> getServiceByName( String name)
	{
		return servicerepo.findByName(name);
	}
	
	public String removeAll()
	{
		servicerepo.deleteAll();
		return "deleted Successfully";
	}


}
