package com.ekantheswar.wash.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ekantheswar.wash.models.scheduleLater;

import com.ekantheswar.wash.services.scheduleLaterService;

@RestController
@RequestMapping("/schedule")
@CrossOrigin()
public class scheduleLaterController {
	@Autowired
	private scheduleLaterService schedulelaterservice;
	
	@PostMapping("/addwash")
	public String addOrder( @RequestBody scheduleLater data) 
	{
		return schedulelaterservice.addOrder(data);
		
	}

	@GetMapping("/scheduledwashes")
	public List<scheduleLater> getwashRequests()
	{
		return schedulelaterservice.getwashRequests();
	}
	
	
	@GetMapping("/scheduledwashes/{c_number}")
	public List<scheduleLater> getrequestByCarNumber( String c_number)
	{
		return schedulelaterservice.getrequestByCarNumber(c_number);
	}
	

}
