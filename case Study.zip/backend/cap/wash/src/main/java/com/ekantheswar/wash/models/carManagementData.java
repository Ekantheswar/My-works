package com.ekantheswar.wash.models;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="car")
public class carManagementData {
	
	private String name;
	private String company;
	private String type;
	
	public carManagementData(String name, String company, String type) {
		super();
		this.name = name;
		this.company = company;
		this.type = type;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	

}
