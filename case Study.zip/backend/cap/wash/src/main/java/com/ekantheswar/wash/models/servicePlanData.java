package com.ekantheswar.wash.models;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="serviceplan")
public class servicePlanData {
	private String name;
	private String cost;
	private String feature;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	public String getFeature() {
		return feature;
	}
	public void setFeature(String feature) {
		this.feature = feature;
	}
	

}
