package com.ekantheswar.wash.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Repository;

import com.ekantheswar.wash.models.servicePlanData;


@EnableMongoRepositories
@Repository

public interface serviceRepo extends MongoRepository<servicePlanData, String> {
	   @Query("{'name':?0}")
	   List<servicePlanData> findByName(String name);
	   
//	   @Query(value = "{'name}:?0",Delete=true)
//	   public 
	   
	   @DeleteQuery
	   String deleteByName(String name);

}
