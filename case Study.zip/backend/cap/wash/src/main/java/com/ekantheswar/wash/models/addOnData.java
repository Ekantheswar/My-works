package com.ekantheswar.wash.models;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="addon")
public class addOnData {
	

}
