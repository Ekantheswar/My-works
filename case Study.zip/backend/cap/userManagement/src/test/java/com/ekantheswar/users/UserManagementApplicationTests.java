package com.ekantheswar.users;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.ekantheswar.users.models.userDetails;
import com.ekantheswar.users.services.adminService;


@RunWith(SpringRunner.class)
@SpringBootTest
class UserManagementApplicationTests {
	
@Autowired
private adminService service;



	@Test
	void contextLoads() {
		
		
	}
	@Test
	@DisplayName("testing of get users")
	void context() {
		assertNotEquals(0, service.getusers().size());
		}

	
	@Test
	@DisplayName("testing of get user")
	void context1()
	{
		assertNotEquals(1, service.getUser("3"));
	}
	
	
	@Test
	@DisplayName("testing of get user by name")
	void context3()
	{
		assertNotEquals(1,service.getUserByName("eswar"));
	}
	
	@Test
	@DisplayName("testing for get user by mail and pass")
	void context4()
	{
		assertNotEquals(1, service.getbymailpass("eswar@gmail.com", "1234"));
	}
	
	@Test
	@DisplayName("testing for save user")
	void context5()
	{
		userDetails user= new userDetails("1","eswar","eswar@gmail.com","password","active","admin");
		assertNotEquals("not equal",service.saveUser(user));
	}
	
}
