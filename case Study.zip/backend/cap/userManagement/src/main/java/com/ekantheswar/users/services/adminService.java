package com.ekantheswar.users.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ekantheswar.users.exceptions.NotFoundException;
import com.ekantheswar.users.models.userDetails;
import com.ekantheswar.users.repositories.usersRepo;


@Service
public class adminService {
	
	@Autowired
	private usersRepo dbs;
	
		
		public List<userDetails> getusers()
		{
			return dbs.findAll();
		}
		
		public Optional<userDetails>getUser(String id)
		{


	      Optional<userDetails> userId = dbs.findById(id);
	      if(!userId.isPresent()) {
	        throw new NotFoundException("User with the id "+ id + " not exist");}
			return dbs.findById(id);
			
		}
		
		
		public List<userDetails> getUserByName( String name)
		{
			return dbs.findByName(name);
		}
		
		
		
		public String removeUser( String id)
		{
		  dbs.deleteById(id);
		  
		  return "User with ID:"+ id + " Deleted Sucessfully";
		}
		
		
		public String removeAll()
		{
			dbs.deleteAll();
			return "deleted Successfully";
		}
		
		
		public String saveUser( userDetails details) 
		{
			System.out.println(details);
			dbs.save(details);
			return"added successfully";
		}
	
		public String updateUser(userDetails d, String s)
		{
			Optional<userDetails> saved = dbs.findById(s);
		    if(!saved.isPresent()){
		      throw new NotFoundException("AddOn with the id "+ s + "not exist");}
		    dbs.save(d);
		    return "User Updated Successfully!!";
		    
		}
		
		public userDetails getbymailpass(String mail,String pass)
		{  
			System.out.println(mail+"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
			List<userDetails> v= new ArrayList<>();
			 v=dbs.findBymail(mail, pass);
			userDetails dd=new userDetails();
			for(userDetails d:v)
			{
				if(d.getMail().equals(mail))
				{
					dd=d;
				}
			}
			return dd;
			 
		}

		
	
}
