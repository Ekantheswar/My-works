package com.ekantheswar.users.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ekantheswar.users.models.userDetails;
import com.ekantheswar.users.services.adminService;


@RestController
@RequestMapping("/admin")
@CrossOrigin()
public class adminController {
	
	@Autowired
	adminService service;
	                                                    //Fetching all user details
	@GetMapping("/getUsers")
	public List<userDetails> getusers()
	{
		return service.getusers();
	}
	                                                    //Fetching user with specific id
	@GetMapping("/getUsers/{id}")
	public Optional<userDetails>getUser(@PathVariable String id)
	{
	return service.getUser(id);	
	}
	
														//Fetching user with specific name
	@GetMapping("/getUser/{name}")
	public List<userDetails> getUserByName( @PathVariable String name)
	{
		return service.getUserByName(name);
	}
	
														//Deleting user with specific id
	@DeleteMapping("/removeUsers/{id}")
	public String removeUser( @PathVariable String id)
	{
		return service.removeUser(id);
	}
	
														//Deleting all user details
	@DeleteMapping("/removeUsers")
	public String removeAll()
	{
		return service.removeAll();
	}
	
														//Adding user
	@PostMapping("/addUser")
	public String saveUser( @RequestBody userDetails details) 
	{
		details.setRole("customer");
		details.setStatus("Active");
		return service.saveUser(details);
		
	}
														//updating user
	@PutMapping("/updateUser/{s}")
	public String updateUser(@RequestBody userDetails d,@PathVariable String s)
	{
		
	    return service.updateUser(d, s);
	    
	}
	

	}


