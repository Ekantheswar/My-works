package com.ekantheswar.users.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ekantheswar.users.models.userDetails;
import com.ekantheswar.users.services.adminService;

@RestController
@RequestMapping("/authenticate")
@CrossOrigin()
public class authentication {
	@Autowired
	private adminService service;
	
	@GetMapping("/{mail}/{pass}")
	public userDetails authenticate(@PathVariable String mail,@PathVariable String pass)
	{
		
		return  service.getbymailpass(mail,pass);
				
	}

}
