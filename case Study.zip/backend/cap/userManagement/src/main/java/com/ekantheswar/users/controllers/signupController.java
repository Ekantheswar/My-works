package com.ekantheswar.users.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ekantheswar.users.models.userDetails;
import com.ekantheswar.users.services.adminService;

@RestController
@RequestMapping("/")
@CrossOrigin()
public class signupController {
	@Autowired
	private adminService service;
	
	
	@PostMapping("/signup")
	public String saveUser( @RequestBody userDetails details) 
	{
		return service.saveUser(details);
		
	}
	
	

}
