package com.ekantheswar.users.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Repository;


import com.ekantheswar.users.models.userDetails;
@EnableMongoRepositories
@Repository
public interface usersRepo extends MongoRepository<userDetails, String> {
	@Query("{'name':?0}")
	   List<userDetails> findByName(String name);
	   
	   @Query("{'mail':?0,'pass':?1}")
	   List<userDetails> findBymail(String mail,String pass);

}
