package com.ekantheswar.users.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ekantheswar.users.exceptions.NotFoundException;
import com.ekantheswar.users.models.userDetails;
import com.ekantheswar.users.services.adminService;

@RestController
@RequestMapping("/washer")
@CrossOrigin()
public class washerController {
	@Autowired
	private adminService service;
	@GetMapping("/profile/{id}")
	public Optional<userDetails>getUser(@PathVariable String id)
	{
	return service.getUser(id);	
	}
	@PutMapping("/profile/update/update/{s}")
	public String updateUser(@RequestBody userDetails d,@PathVariable String s)
	{
		return service.updateUser(d, s);
	    
	}

}
