package com.ekantheswar.reviews;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewsAndRatingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
