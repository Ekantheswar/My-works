package com.ekantheswar.reviews.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Repository;
import com.ekantheswar.reviews.models.reviewsData;

@EnableMongoRepositories
@Repository
public interface ratingsRepo extends MongoRepository<reviewsData, String> {
	@Query("{'name':?0},{unique:true}")
	   List<reviewsData> findByName(String name);
	   
	@Query("{'washername':?0},{unique:true}")
	   List<reviewsData> findBywasherName(String washername);
	   
	   
	

}
