package com.ekantheswar.reviews.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;



@Document(collection="reviews")
public class reviewsData {
	@Id
	private String _id;
	private String name;
	private int rating;
	private String washername;
	
	
	public String get_id() {
		return _id;
	}
	public void set_id(String _id) {
		this._id = _id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getWashername() {
		return washername;
	}
	public void setWashername(String washername) {
		this.washername = washername;
	}
	
	public reviewsData(String _id, String name, int rating, String washername) {
		super();
		this._id = _id;
		this.name = name;
		this.rating = rating;
		this.washername = washername;
		
	}
	


}
