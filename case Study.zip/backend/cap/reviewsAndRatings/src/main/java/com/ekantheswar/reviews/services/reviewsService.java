package com.ekantheswar.reviews.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ekantheswar.reviews.models.reviewsData;
import com.ekantheswar.reviews.repositories.ratingsRepo;

@Service
public class reviewsService {

	
	@Autowired
	private ratingsRepo ratingsrepo;
	
	public List<reviewsData> getRatingsByName( String name)
	{
		return ratingsrepo.findByName(name);
	}
	
	public List<reviewsData> getRatingsBywasherName( String washername)
	{
		return ratingsrepo.findBywasherName(washername);
	}
	
	public String saveRating( reviewsData details) 
	{
		ratingsrepo.save(details);
		return"added successfully";
		
	}

}
