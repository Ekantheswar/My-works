package com.ekantheswar.reviews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class ReviewsAndRatingsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReviewsAndRatingsApplication.class, args);
	}

}
