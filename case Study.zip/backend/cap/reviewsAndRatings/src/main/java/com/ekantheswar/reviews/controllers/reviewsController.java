package com.ekantheswar.reviews.controllers;

import java.util.List;

import javax.ws.rs.Path;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ekantheswar.reviews.models.reviewsData;
import com.ekantheswar.reviews.services.reviewsService;

@RestController
@RequestMapping("/ratings")
@CrossOrigin()
public class reviewsController {
	@Autowired reviewsService review;
	
	@GetMapping("/getratings/{washername}")
	public List<reviewsData> getRatingsBywasherName(@PathVariable String washername)
	{
		return review.getRatingsBywasherName(washername);
	}
	
	@GetMapping("/getratings/customer/{name}")
	public List<reviewsData> getRatingsByName(@PathVariable String name)
	{
		return review.getRatingsByName(name);
	}
	
	
	@PostMapping("/addratings")
	public String saveRating(@RequestBody reviewsData details) 
	{
		return review.saveRating(details);
	}
	
	
	

	
	
	
	

}
