import { CusthomeComponent } from './components/custhome/custhome.component';
import { WasherhomeComponent } from './components/washerhome/washerhome.component';
import { WasherordersComponent } from './components/washerorders/washerorders.component';
import { SearchNameComponent } from './components/search-name/search-name.component';
import { UpdateformComponent } from './components/updateform/updateform.component';
import { CustOrderComponent } from './components/cust-order/cust-order.component';
import { OnlyviewServiceComponent } from './components/onlyview-service/onlyview-service.component';
import { NewCarComponent } from './components/new-car/new-car.component';
import { CarDetailsComponent } from './components/car-details/car-details.component';
import { DummyHomeComponent } from './components/dummy-home/dummy-home.component';
import { AdminUsersComponent } from './components/admin-users/admin-users.component';
import { WasherUIComponent } from './components/washer-ui/washer-ui.component';
import { CustUIComponent } from './components/cust-ui/cust-ui.component';
import { AdminUIComponent } from './components/admin-ui/admin-ui.component';
import { AddserviceplanComponent } from './components/addserviceplan/addserviceplan.component';
import { AdduserComponent } from './components/adduser/adduser.component';
import { WashComponent } from './components/wash/wash/wash.component';
import { ServiceplanComponent } from './components/serviceplan/serviceplan.component';


import { SignupComponent } from './components/signup/signup.component';
import { ServicesComponent } from './components/services/services.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { LoginComponent } from './components/login/login.component';

import { HomeComponent } from './components/home/home.component';
import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import{ActivatedRoute,Router} from '@angular/router';

const routes: Routes =
[
  {path:"",component:HomeComponent},
  {path:'home',component:HomeComponent},
  {path:'details',component:SignupComponent },
  {path:"login",component:LoginComponent},
  {path:"signup",component:SignupComponent},
  {path:"admin",component:AdminUIComponent},
  {path:"customer",component:CustUIComponent},
  {path:"washer",component:WasherUIComponent},
  {path:'serviceplan',component:ServiceplanComponent},
  {path:'customers',component:AdminUsersComponent},
  {path:'services',component:ServicesComponent},
  {path:'about',component:AboutUsComponent},
  {path:'adduser',component:AdduserComponent},
  {path:'addservice',component:AddserviceplanComponent},
  {path:'homed',component:DummyHomeComponent},
  {path:'cars',component:CarDetailsComponent},
  {path:'newcar',component:NewCarComponent},
  {path:'viewservice',component:OnlyviewServiceComponent},
  {path:'custorders',component:CustOrderComponent},
  {path:'updateuser',component:UpdateformComponent},
  {path:'washerorder',component:WasherordersComponent},
  {path:'washerhome',component:WasherhomeComponent},
  {path:'custhome',component:CusthomeComponent}







];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
