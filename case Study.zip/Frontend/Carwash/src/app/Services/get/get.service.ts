import { Cardata } from './../../classes/carData/cardata';
import { Wash } from './../../classes/wash/wash';
import { User } from './../../classes/user';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {Serviceplan} from './../../classes/servicePlan/serviceplan';


@Injectable({
  providedIn: 'root'
})
export class GetService {



  constructor(private http:HttpClient) { }









// ServicePlan
//working
public getServices():Observable<any>
 {
 return  this.http.get("http://localhost:8084/service/getServices");

 }

 public removeServices():Observable<any>
 {
   return this.http.delete("http://localhost:8084/service/removeAll")
 }

 //Fetch Service by Id
public getByName(plan:Serviceplan):Observable<any>{
  return this.http.get("http://localhost:8084/service/getservice/"+plan.name)
}

public addservice(plan:Serviceplan):Observable<any>
{
  return this.http.post("http://localhost:8084/service/addService",plan)
}

public deleteServiceByID(plan:Serviceplan):Observable<any>
{
  return this.http.delete("http://localhost:8084/service/removeService/"+plan.name)
}




 //Users
//Working
 public create(user:User): Observable<any> {
return this.http.post<User>("http://localhost:8081/admin/addUser",user,{responseType:'text' as 'json'})
}


public auth(user:User):Observable<any>{
  return this.http.get("http://localhost:8081/authenticate/"+user.mail+"/"+user.pass)
}

public getUsers():Observable<any>
{
  return this.http.get("http://localhost:8081/admin/getUsers");

}

public deleteUsers():Observable<any>
{
  return this.http.delete("http://localhost:8081/admin/removeUsers")
}


public searchByName(user:User):Observable<any>
{
  return this.http.get("http://localhost:8081/admin/getUser/"+user.name)
}

public UpdateUser(user:User):Observable<any>
{
  return this.http.put("http://localhost:8081/admin/updateUser/"+user._id,user)
}
public getuserByID(id:any):Observable<any>
{
  return this.http.get("http://localhost:8081/admin/getUsers/"+id)
}

public deleteByID(id:any):Observable<any>
{
  return this.http.delete("http://localhost:8081/admin/removeUsers/"+id)
}










//wash
//DeleteAll
public deleteAll():Observable<any>
{
  return this.http.delete("http://localhost:8084/wash/deleteAll")
}
public getOrders():Observable<any>
 {
 return this.http.get("http://localhost:8084/wash/getWashRequests")

 }

 public addOrder(order:Wash):Observable<any>
 {
   return this.http.post("http://localhost:8084/wash/addWashRequest",order)
 }

 public getorderName(plan:any):Observable<any>{
  return this.http.get("http://localhost:8084/wash/getorders/"+plan)
}




 ///CarDetails
 //getCarDetails

 public getCars():Observable<any>
 {
 return this.http.get("http://localhost:8084/carManage/getCars");
 }
 public deleteCars():Observable<any>
 {
 return this.http.delete("http://localhost:8084/carManage/removeCars")

 }

 public addCar(car:Cardata):Observable<any>
 {
   return this.http.post("http://localhost:8084/carManage/addCar",car)
 }

 public deletecar(car:Cardata):Observable<any>
 {
   return this.http.delete("http://localhost:8084/carManage/removeCar/"+car.name)
 }



}


