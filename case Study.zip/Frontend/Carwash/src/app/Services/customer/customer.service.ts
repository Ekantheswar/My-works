import { Wash } from './../../classes/wash/wash';
import { User } from './../../classes/user';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http:HttpClient) { }

public getcustomer(cust:User):Observable<any>
{
  return this.http.get("http://localhost:8081/customer/profile/"+cust._id)
}


public customerUpdate(cust:User):Observable<any>
{
  return this.http.get("http://localhost:8081/customer/profile/update"+cust._id)
}


public customerOrders(cust:Wash):Observable<any>
{
  return this.http.get("http://localhost:8084/wash/getorders/"+cust.name)
}

}
