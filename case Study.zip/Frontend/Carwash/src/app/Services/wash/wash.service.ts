import { Wash } from './../../classes/wash/wash';
import { Observable } from 'rxjs';
import { User } from './../../classes/user';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';



@Injectable({
  providedIn: 'root'
})
export class WashService {


  constructor(private http:HttpClient) { }

public getWasher(washer:User):Observable<any>
{
return this.http.get("http://localhost:8081/washer/profile/"+washer._id)
}

public updateWasher(washer:User):Observable<any>
{
return this.http.put("http://localhost:8081/washer/profile/update"+washer._id,washer)
}

public getOrders(washer:Wash):Observable<any>
{
  return this.http.get("http://localhost:8084/wash/getorders/"+washer.w_name)
}

}
