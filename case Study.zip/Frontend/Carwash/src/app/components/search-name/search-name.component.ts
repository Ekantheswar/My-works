import { GetService } from './../../Services/get/get.service';
import { User } from './../../classes/user';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-search-name',
  templateUrl: './search-name.component.html',
  styleUrls: ['./search-name.component.css']
})
export class SearchNameComponent implements OnInit {


  user2=new User;
  constructor(private user:GetService) { }

  ngOnInit(): void {

  }
  public searchByName()
  {
    this.user.searchByName(this.user2).subscribe(data=>{this.user2=data;})
  }

  public deleteByName()
  {
    this.user.deleteByID(this.user2).subscribe(data=>console.log("deleted Successfully"))
  }
}
