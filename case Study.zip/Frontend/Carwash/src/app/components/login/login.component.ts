import { AuthService } from './../../Services/auth/auth.service';
import { User } from './../../classes/user';
import { GetService } from './../../Services/get/get.service';
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import {ActivatedRoute,Router} from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user=new User();
  private route:ActivatedRoute;
  constructor(private service:GetService,private router:Router) { }

  ngOnInit(): void {

  }

  public loginUser()
  {
    this.service.auth(this.user).subscribe(data=>{localStorage.setItem("role",data.role),
    localStorage.setItem("userid",data._id),
  localStorage.setItem("mail",data.mail),
  localStorage.setItem("pass",data.pass),
localStorage.setItem("name",data.name)
}
  )

    if(this.user.mail==localStorage.getItem("mail")&& this.user.pass==localStorage.getItem("pass"))
    {

      if(localStorage.getItem("role")=="admin")
      {
        this.router.navigate(['/admin']);
        alert("Welcome Admin");
      }
      else{
        if(localStorage.getItem("role")=="customer")
        {
          this.router.navigate(['/customer']);
        }
        else{
          this.router.navigate(['washer']);
        }
      }
    }
    else
    {
      console.log("invalid credentials")
    }
  }



public logout()
{
this.router.navigate(['http://localhost:4200/']);
}









}
