import { Cardata } from './../../classes/carData/cardata';
import { GetService } from './../../Services/get/get.service';
import { Component, OnInit } from '@angular/core';

import {ActivatedRoute,Router} from '@angular/router';


@Component({
  selector: 'app-new-car',
  templateUrl: './new-car.component.html',
  styleUrls: ['./new-car.component.css']
})
export class NewCarComponent implements OnInit {
  car2=new Cardata;

  constructor(private router:Router,private service:GetService) { }

  ngOnInit(): void {
  }

  public addCar()
  {
    this.service.addCar(this.car2).subscribe(data=>console.log("data"),error=>console.log("error"))
  }


public logout()
{
this.router.navigate(['home']);
alert("see you again");
}









}
