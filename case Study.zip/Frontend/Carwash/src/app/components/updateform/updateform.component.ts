import { User } from './../../classes/user';
import { GetService } from './../../Services/get/get.service';
import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';


@Component({
  selector: 'app-updateform',
  templateUrl: './updateform.component.html',
  styleUrls: ['./updateform.component.css']
})
export class UpdateformComponent implements OnInit {

  user=new User;
  r:any;
  form:any;

  constructor(private service:GetService,private router:Router) { }
  user2 = new User;
  user3= new User;

  ngOnInit(): void {

  }

  public updateUser()
  {
    this.service.UpdateUser(this.user).subscribe(data=>console.log(data),error=>console.log("error"))
  }
  public logout()
  {
  this.router.navigate(['home']);
  alert("see you again");
  }
  public searchByName()
  {
    this.service.searchByName(this.user2).subscribe(data=>{this.user3=data;})
  }
}
