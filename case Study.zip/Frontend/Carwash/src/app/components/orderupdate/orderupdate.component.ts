import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orderupdate',
  templateUrl: './orderupdate.component.html',
  styleUrls: ['./orderupdate.component.css']
})
export class OrderupdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
