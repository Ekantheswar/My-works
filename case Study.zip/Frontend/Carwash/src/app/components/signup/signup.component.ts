
import { Observable } from 'rxjs';
import { User } from './../../classes/user';

import { GetService } from './../../Services/get/get.service';


import {Component,  OnInit } from '@angular/core';



@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  user=new User();



  constructor(private _service:GetService) { }

  ngOnInit() {

  }



  public getusers()
  {
    let res= this._service.getUsers();

  }

  public getServices()
  {
    return this._service.getServices();

  }


  //working

 public addUser()
 {
   this._service.create(this.user).subscribe(
     data=>console.log(console.log(data)),
     error=>console.log("exception occured")
   )
 }





}


