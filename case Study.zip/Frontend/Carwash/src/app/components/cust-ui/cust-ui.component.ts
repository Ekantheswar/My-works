import { Component, OnInit } from '@angular/core';



import {ActivatedRoute,Router} from '@angular/router';

@Component({
  selector: 'app-cust-ui',
  templateUrl: './cust-ui.component.html',
  styleUrls: ['./cust-ui.component.css']
})
export class CustUIComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  public logout()
{
this.router.navigate(['home']);
alert("see you again");
}





}
