import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustUIComponent } from './cust-ui.component';

describe('CustUIComponent', () => {
  let component: CustUIComponent;
  let fixture: ComponentFixture<CustUIComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustUIComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustUIComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
