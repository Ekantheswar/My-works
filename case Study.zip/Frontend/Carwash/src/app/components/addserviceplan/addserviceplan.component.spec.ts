import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddserviceplanComponent } from './addserviceplan.component';

describe('AddserviceplanComponent', () => {
  let component: AddserviceplanComponent;
  let fixture: ComponentFixture<AddserviceplanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddserviceplanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddserviceplanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
