import { Serviceplan } from './../../classes/servicePlan/serviceplan';
import { GetService } from './../../Services/get/get.service';
import { Component, OnInit } from '@angular/core';





import {ActivatedRoute,Router} from '@angular/router';


@Component({
  selector: 'app-addserviceplan',
  templateUrl: './addserviceplan.component.html',
  styleUrls: ['./addserviceplan.component.css']
})
export class AddserviceplanComponent implements OnInit {
plan=new Serviceplan;
  constructor(private service:GetService,private router:Router) { }

  ngOnInit(): void {
  }
  public addService()
  {
    this.service.addservice(this.plan).subscribe(data=>console.log(data),error=>console.log("error"));
    alert("Service added successfully");


  }



  public logout()
  {
  this.router.navigate(['home']);
  alert("see you again");
  }


}
