import { Serviceplan } from './../../classes/servicePlan/serviceplan';
import { GetService } from './../../Services/get/get.service';
import { Wash } from './../../classes/wash/wash';
import { Component, OnInit } from '@angular/core';





import {ActivatedRoute,Router} from '@angular/router';

@Component({
  selector: 'app-cust-order',
  templateUrl: './cust-order.component.html',
  styleUrls: ['./cust-order.component.css']
})
export class CustOrderComponent implements OnInit {


  selectedValue: string;
  user=new Wash;
  serviceplan:Serviceplan[]

  constructor(private service:GetService,private router:Router) { }



  ngOnInit(): void {
  }

  public addOrder()
  {
    this.service.addOrder(this.user).subscribe(data=>console.log(data)
    )
  }

  public getserviceplan()
  {
    this.service.getServices().subscribe(data=>console.log(data))
  }


public logout()
{
this.router.navigate(['home']);
alert("see you again");
}
}
