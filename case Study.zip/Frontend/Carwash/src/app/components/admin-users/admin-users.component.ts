import { User } from './../../classes/user';
import { GetService } from './../../Services/get/get.service';
import { Component, OnInit } from '@angular/core';



import {ActivatedRoute,Router} from '@angular/router';


@Component({
  selector: 'app-admin-users',
  templateUrl: './admin-users.component.html',
  styleUrls: ['./admin-users.component.css']
})
export class AdminUsersComponent implements OnInit {

  user1:User[];
  user2=new User;

  constructor(private user:GetService,private router:Router) { }

  ngOnInit(): void {
    this.user.getUsers().subscribe(data=>{this.user1=data;
    })

  }

  public deleteUsers()
  {this.user.deleteUsers().subscribe(data=>console.log("deleted successfully"))}

  public update()
  {
    this.user.UpdateUser(this.user2).subscribe(data=>console.log("updated successfully"))
  }

  public deletebyid(user2)
  {

    this.user.deleteByID(user2).subscribe(data=>console.log("deleted successfully"))
  }



  public logout()
{
this.router.navigate(['home']);
alert("see you again");
}

}
