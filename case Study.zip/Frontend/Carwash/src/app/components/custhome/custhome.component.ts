import { Component, OnInit } from '@angular/core';




import {ActivatedRoute,Router} from '@angular/router';

@Component({
  selector: 'app-custhome',
  templateUrl: './custhome.component.html',
  styleUrls: ['./custhome.component.css']
})
export class CusthomeComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  public logout()
  {
  this.router.navigate(['home']);
  alert("see you again");
  }



}
