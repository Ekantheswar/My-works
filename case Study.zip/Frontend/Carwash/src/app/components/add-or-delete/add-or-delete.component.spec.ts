import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOrDeleteComponent } from './add-or-delete.component';

describe('AddOrDeleteComponent', () => {
  let component: AddOrDeleteComponent;
  let fixture: ComponentFixture<AddOrDeleteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddOrDeleteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOrDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
