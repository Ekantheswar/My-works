import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-or-delete',
  templateUrl: './add-or-delete.component.html',
  styleUrls: ['./add-or-delete.component.css']
})
export class AddOrDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
