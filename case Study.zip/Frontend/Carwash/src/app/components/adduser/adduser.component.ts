import { User } from './../../classes/user';
import { GetService } from './../../Services/get/get.service';
import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
  user=new User;

  constructor(private adduser: GetService,private router:Router) { }

  ngOnInit(): void {
  }

  public addUser()
  {
    this.adduser.create(this.user).subscribe(data=>console.log(data),error=>console.log("error"))
  }




public logout()
{
this.router.navigate(['home']);
alert("see you again");
}






}
