import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-home',
  templateUrl: './basic-home.component.html',
  styleUrls: ['./basic-home.component.css']
})
export class BasicHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
