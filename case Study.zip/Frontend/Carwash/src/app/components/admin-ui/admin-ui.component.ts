import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';

@Component({
  selector: 'app-admin-ui',
  templateUrl: './admin-ui.component.html',
  styleUrls: ['./admin-ui.component.css']
})
export class AdminUIComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }



public logout()
{
this.router.navigate(['home']);
alert("see you again");
}
}
