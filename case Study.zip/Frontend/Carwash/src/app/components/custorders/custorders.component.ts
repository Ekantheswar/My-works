import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custorders',
  templateUrl: './custorders.component.html',
  styleUrls: ['./custorders.component.css']
})
export class CustordersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
