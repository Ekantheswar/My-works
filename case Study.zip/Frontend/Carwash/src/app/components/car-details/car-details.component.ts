import { GetService } from './../../Services/get/get.service';
import { Cardata } from './../../classes/carData/cardata';
import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';


@Component({
  selector: 'app-car-details',
  templateUrl: './car-details.component.html',
  styleUrls: ['./car-details.component.css']
})
export class CarDetailsComponent implements OnInit {
  car: Cardata[];
  car2=new Cardata;

  constructor(private service:GetService,private router:Router) { }

  ngOnInit(): void {
    this.service.getCars().subscribe(data=>{this.car=data})
  }
public deletecardetails()
{
this.service.deleteCars().subscribe(
  data=>console.log("data"),error=>console.log("error"))
}

public addCar()
{
  this.service.addCar(this.car2).subscribe(data=>console.log("data"),error=>console.log("error"))
}


public deletebyid(car2)
  {

    this.service.deleteByID(car2).subscribe(data=>console.log("deleted successfully"))
  }

public logout()
{
this.router.navigate(['home']);
alert("see you again");
}
}
