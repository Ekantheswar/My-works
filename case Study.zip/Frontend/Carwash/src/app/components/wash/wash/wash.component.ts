import { Wash } from './../../../classes/wash/wash';
import { GetService } from './../../../Services/get/get.service';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-wash',
  templateUrl: './wash.component.html',
  styleUrls: ['./wash.component.css']
})
export class WashComponent implements OnInit {

  wash:Wash[];
  constructor(private service:GetService) { }

  ngOnInit(): void {

    this.service.getOrders().subscribe(data=>{this.wash=data
    })


  }

  public removeall()
  {
    this.service.deleteAll().subscribe(data=>console.log("succesful"),error=>console.log("coudn't happen"));
  }


}
