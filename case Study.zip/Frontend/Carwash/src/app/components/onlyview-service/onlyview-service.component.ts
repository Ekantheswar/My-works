import { Serviceplan } from './../../classes/servicePlan/serviceplan';
import { GetService } from './../../Services/get/get.service';
import { Component, OnInit } from '@angular/core';




import {ActivatedRoute,Router} from '@angular/router';

@Component({
  selector: 'app-onlyview-service',
  templateUrl: './onlyview-service.component.html',
  styleUrls: ['./onlyview-service.component.css']
})
export class OnlyviewServiceComponent implements OnInit {


  serviceplan:Serviceplan[]
  constructor(private _serviceplan:GetService,private router:Router) { }

  ngOnInit(): void {

    this._serviceplan.getServices().subscribe(data=>{this.serviceplan=data;
    })
  }
  public logout()
{
this.router.navigate(['home']);
alert("see you again");
}



}
