import { GetService } from './../../Services/get/get.service';
import { Wash } from './../../classes/wash/wash';
import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';

@Component({
  selector: 'app-washerorders',
  templateUrl: './washerorders.component.html',
  styleUrls: ['./washerorders.component.css']
})
export class WasherordersComponent implements OnInit {

wash:Wash[];
  r:any;
  constructor( private router:Router,private service:GetService) { }

  ngOnInit(): void {
    let r=localStorage.getItem("name");
    console.log(r);
    this.service.getorderName(r).subscribe(data=>{this.wash=data;})


  }

  public logout()
  {
  this.router.navigate(['home']);
  alert("see you again");
  }

  public getOrderByName()
  {

  }






}
