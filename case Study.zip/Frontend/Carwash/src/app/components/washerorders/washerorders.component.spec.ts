import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WasherordersComponent } from './washerorders.component';

describe('WasherordersComponent', () => {
  let component: WasherordersComponent;
  let fixture: ComponentFixture<WasherordersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WasherordersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WasherordersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
