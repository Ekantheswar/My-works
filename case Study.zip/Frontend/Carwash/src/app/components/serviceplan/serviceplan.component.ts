import { Serviceplan } from './../../classes/servicePlan/serviceplan';
import { GetService } from './../../Services/get/get.service';


import { Component, OnInit } from '@angular/core';

import {ActivatedRoute,Router} from '@angular/router';


@Component({
  selector: 'app-serviceplan',
  templateUrl: './serviceplan.component.html',
  styleUrls: ['./serviceplan.component.css']
})
export class ServiceplanComponent implements OnInit {
  user2=new Serviceplan;

  serviceplan:Serviceplan[];

  constructor(private _serviceplan:GetService,private router:Router) { }

  ngOnInit(): void {

    this._serviceplan.getServices().subscribe(data=>{this.serviceplan=data;
    })
    }


//Delete All
public deleteall()
{
  this._serviceplan.removeServices().subscribe(data=>console.log("deleted succesfully"))
}

public deletebyid(user2)
  {

    this._serviceplan.deleteServiceByID(user2).subscribe(data=>console.log("deleted successfully"))
  }




  public logout()
  {
  this.router.navigate(['home']);
  alert("see you again");
  }


}
