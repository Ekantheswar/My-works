export class User {
   _id:String;
  name:String;
  mail:String;
  pass:String;
  status:String;
  role:String;

  constructor( ){


    }

}
