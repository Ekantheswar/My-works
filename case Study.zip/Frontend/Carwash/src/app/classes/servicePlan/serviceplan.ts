export class Serviceplan {
  name:String;
  cost:String;
  feature:String;

  constructor()
  {

  }
}
