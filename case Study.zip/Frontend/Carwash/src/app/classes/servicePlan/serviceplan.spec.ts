import { Serviceplan } from './serviceplan';

describe('Serviceplan', () => {
  it('should create an instance', () => {
    expect(new Serviceplan()).toBeTruthy();
  });
});
