import { Cardata } from './cardata';

describe('Cardata', () => {
  it('should create an instance', () => {
    expect(new Cardata()).toBeTruthy();
  });
});
