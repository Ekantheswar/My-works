export class Cardata {
  _id:any;
  name:String;
  company:String;
  type:String;
  constructor()
  {

  }
}
