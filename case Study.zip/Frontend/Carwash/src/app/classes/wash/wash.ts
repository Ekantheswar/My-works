export class Wash {
  _id:String;
  name:String;
  w_name:String;
  c_number:String;
  c_type:String;
  c_company:String;
  c_name:String;
  status:String;
  cost:String;

  constructor()
  {

  }
}
