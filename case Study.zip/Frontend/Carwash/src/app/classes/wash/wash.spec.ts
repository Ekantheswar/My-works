import { Wash } from './wash';

describe('Wash', () => {
  it('should create an instance', () => {
    expect(new Wash()).toBeTruthy();
  });
});
