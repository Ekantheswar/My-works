import { AuthService } from './Services/auth/auth.service';
import { CustomerService } from './Services/customer/customer.service';
import { WashService } from './Services/wash/wash.service';

import { GetService } from './Services/get/get.service';
import { SignupComponent } from './components/signup/signup.component';


import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NavbarComponent } from './components/navbar/navbar.component';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonModule} from '@angular/material/button';
import { LoginComponent } from './components/login/login.component';
import {MatCardModule} from '@angular/material/card';
import {MatTabsModule} from '@angular/material/tabs';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatIconModule} from '@angular/material/icon';
import { FormsModule, NgModel, ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './components/home/home.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { ProfileComponent } from './components/profile/profile.component';
import { FooterComponent } from './components/footer/footer.component';
import { BodyComponent } from './components/body/body.component';
import { ServicesComponent } from './components/services/services.component';
import {MatGridListModule} from '@angular/material/grid-list';
import { ReceiptComponent } from './components/receipt/receipt.component';
import { ProductsComponent } from './components/products/products.component';
import { AddOrDeleteComponent } from './components/add-or-delete/add-or-delete.component';
import { HttpClientModule } from '@angular/common/http';
import { PaymentComponent } from './components/payment/payment.component';

import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { MatMenuModule } from '@angular/material/menu';
import { LayoutModule } from '@angular/cdk/layout';
import { ServiceplanComponent } from './components/serviceplan/serviceplan.component';
import { WashComponent } from './components/wash/wash/wash.component';
import { CarDetailsComponent } from './components/car-details/car-details.component';
import { AdminUsersComponent } from './components/admin-users/admin-users.component';
import { SearchNameComponent } from './components/search-name/search-name.component';
import { UpdateformComponent } from './components/updateform/updateform.component';
import { AdduserComponent } from './components/adduser/adduser.component';
import { AddserviceplanComponent } from './components/addserviceplan/addserviceplan.component';
import { OnlyviewServiceComponent } from './components/onlyview-service/onlyview-service.component';
import { CustOrderComponent } from './components/cust-order/cust-order.component';
import { AdminUIComponent } from './components/admin-ui/admin-ui.component';
import { BasicHomeComponent } from './components/basic-home/basic-home.component';
import { CustUIComponent } from './components/cust-ui/cust-ui.component';
import { WasherUIComponent } from './components/washer-ui/washer-ui.component';
import { DummyHomeComponent } from './components/dummy-home/dummy-home.component';
import { NewCarComponent } from './components/new-car/new-car.component';
import { CustordersComponent } from './components/custorders/custorders.component';
import { OrderupdateComponent } from './components/orderupdate/orderupdate.component';
import { WasherordersComponent } from './components/washerorders/washerorders.component';
import { WasherhomeComponent } from './components/washerhome/washerhome.component';
import { CusthomeComponent } from './components/custhome/custhome.component';







@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    HomeComponent,
    AboutUsComponent,
    ProfileComponent,
    FooterComponent,
    BodyComponent,
    ServicesComponent,
    ReceiptComponent,
    ProductsComponent,
    AddOrDeleteComponent,
    PaymentComponent,
    DashboardComponent,
    SignupComponent,

    ServiceplanComponent,
     WashComponent,
     CarDetailsComponent,
     AdminUsersComponent,
     SearchNameComponent,
     UpdateformComponent,
     AdduserComponent,
     AddserviceplanComponent,
     OnlyviewServiceComponent,
     CustOrderComponent,
     AdminUIComponent,
     BasicHomeComponent,
     CustUIComponent,
     WasherUIComponent,
     DummyHomeComponent,
     NewCarComponent,
     CustordersComponent,
     OrderupdateComponent,
     WasherordersComponent,
     WasherhomeComponent,
     CusthomeComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatButtonModule,
    MatCardModule,
    MatTabsModule,
    MatFormFieldModule,
    MatInputModule,
    MatCheckboxModule,
    MatIconModule,
    FormsModule,
    MatGridListModule,
    HttpClientModule,
    MatSelectModule,
    MatRadioModule,
    ReactiveFormsModule,
    MatMenuModule,
    LayoutModule,


  ],
  providers: [GetService,WashService,CustomerService,AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
